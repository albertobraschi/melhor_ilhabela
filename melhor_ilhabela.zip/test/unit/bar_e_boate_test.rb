require 'test_helper'

class BarEBoateTest < ActiveSupport::TestCase
  def test_should_be_valid
    assert BarEBoate.new.valid?
  end
end
