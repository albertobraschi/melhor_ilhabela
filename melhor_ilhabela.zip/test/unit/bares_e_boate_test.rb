require 'test_helper'

class BaresEBoateTest < ActiveSupport::TestCase
  def test_should_be_valid
    assert BaresEBoate.new.valid?
  end
end
