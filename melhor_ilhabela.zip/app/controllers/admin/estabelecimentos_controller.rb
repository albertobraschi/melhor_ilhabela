class Admin::EstabelecimentosController < ApplicationController
  #load_and_authorize_resource
  before_filter :login_required
  layout "admin"

  def index
    @col = "col2-right"
    @estabelecimentos = Estabelecimento.all
    @caso = BaresEBoate.find_by_estabelecimento_id(@estabelecimentos.id)
  end

  def show
    @col = "col1"
    @estabelecimento = Estabelecimento.find(params[:id])
    @caso = @estabelecimento.tipo_estabelecimento
    @resultado = case @caso
      when "BECN"
        @caso = BaresEBoate.find_by_estabelecimento_id(@estabelecimento.id)
      when "REST"
        @caso = Restaurante.find_by_estabelecimento_id(@estabelecimento.id)
      when "IPLT"
        @caso = ImovelLocacao.find_by_estabelecimento_id(@estabelecimento.id)
      when "HEPO"
        @caso = HoteisPousada.find_by_estabelecimento_id(@estabelecimento.id)
    end
  end

  def new
    @col = "col2-right"
    @estabelecimento = Estabelecimento.new
  end

  def create
    @estabelecimento = Estabelecimento.new(params[:estabelecimento])
    if @estabelecimento.save
        @redireciona_tipo_estabelecimento = @estabelecimento.tipo_estabelecimento
        case @redireciona_tipo_estabelecimento
          when "BECN" then redirect_to new_admin_estabelecimento_bares_e_boate_path(@estabelecimento)
          when "REST" then redirect_to new_admin_estabelecimento_restaurante_path(@estabelecimento)
          when "IPLT" then redirect_to new_admin_estabelecimento_imovel_locacao_path(@estabelecimento)
          when "HEPO" then redirect_to new_admin_estabelecimento_hoteis_pousada_path(@estabelecimento)
        else
          flash[:notice] = "falhou!"
          render :action => 'new'
        end
    else
      render :action => 'new'
    end
  end

  def edit
    @estabelecimento = Estabelecimento.find(params[:id])
  end

  def update
    @estabelecimento = Estabelecimento.find(params[:id])
    if @estabelecimento.update_attributes(params[:estabelecimento])
      flash[:notice] = "Successfully updated estabelecimento."
      redirect_to @estabelecimento
    else
      render :action => 'edit'
    end
  end

  def destroy
    @estabelecimento = Estabelecimento.find(params[:id])
    @estabelecimento.destroy
    redirect_to admin_estabelecimentos_url
  end
end

