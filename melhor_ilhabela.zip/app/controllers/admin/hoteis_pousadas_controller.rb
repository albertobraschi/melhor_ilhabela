class Admin::HoteisPousadasController < ApplicationController
  before_filter :login_required
  layout 'admin'

  def index
    @hoteis_pousadas = HoteisPousada.all
  end

  def show
    @hoteis_pousada = HoteisPousada.find(params[:id])
  end

  def new
    @col = "col1"
    @estabelecimento = Estabelecimento.find(params[:estabelecimento_id])
    @hoteis_pousada = @estabelecimento.hoteis_pousada.build
  end

  def create
    @estabelecimento = Estabelecimento.find(params[:estabelecimento_id])
    @hoteis_pousada = @estabelecimento.hoteis_pousada.build(params[:hoteis_pousada])
    if @hoteis_pousada.save
      redirect_to @hoteis_pousada
    else
      render :action => 'new'
    end
  end

  def edit
    @hoteis_pousada = HoteisPousada.find(params[:id])
  end

  def update
    @hoteis_pousada = HoteisPousada.find(params[:id])
    if @hoteis_pousada.update_attributes(params[:hoteis_pousada])
      flash[:notice] = "Successfully updated hoteis pousada."
      redirect_to @hoteis_pousada
    else
      render :action => 'edit'
    end
  end

  def destroy
    @hoteis_pousada = HoteisPousada.find(params[:id])
    @hoteis_pousada.destroy
    flash[:notice] = "Successfully destroyed hoteis pousada."
    redirect_to hoteis_pousadas_url
  end
end

