class Cliente < ActiveRecord::Base
        attr_accessible :nome_fantasia, :razao_social, :cnpj_estabelecimento, :ramo_atuacao, :endereco_estabelecimento, :numero_estabelecimento, :complemento_estabelecimento, :cep_estabelecimento, :bairro_estabelecimento, :cidade_estabelecimento, :estado_estabelecimento, :telefone_comercial, :telefone_celular, :telefone_fax, :email_estabelecimento, :nome_responsavel, :email_responsavel, :telefone_responsavel

  has_many :estabelecimentos

  def self.search(search)
    if search
      find(:all, :conditions => ['nome_fantasia LIKE ?  OR razao_social LIKE ? OR nome_responsavel LIKE ?', "%#{search}%", "%#{search}%", "%#{search}%"])
    else
      find(:all)
    end
  end
end

