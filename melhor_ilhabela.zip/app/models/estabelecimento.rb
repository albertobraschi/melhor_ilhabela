class Estabelecimento < ActiveRecord::Base
  has_many :bares_e_boate, :dependent => :destroy
  has_many :restaurante, :dependent => :destroy
  has_many :imovel_locacao, :dependent => :destroy
  has_many :hoteis_pousada, :dependent => :destroy
  belongs_to :cliente
end

