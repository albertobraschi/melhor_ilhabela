class Restaurante < ActiveRecord::Base
  attr_accessible :cliente_id, :descricao, :cardapio, :forma_pagamento, :horario_atendimento
  belongs_to :estabelecimento
end

