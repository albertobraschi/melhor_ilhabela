class HoteisPousada < ActiveRecord::Base
  attr_accessible :estabelecimento_id, :apresentacao, :tipo_acomodacao, :caracteristica_acomodacao
  belongs_to :estabelecimento
end

