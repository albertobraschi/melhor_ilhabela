class Ability
  include CanCan::Ability

  def initialize(user)

  end
end

