module BarEBoatesHelper
end
